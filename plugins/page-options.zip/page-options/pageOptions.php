<?php
/**
 *
 * Plugin Name: Page Options
 * Plugin URI: http://farost.net
 * Description: This plugin is package compilation some addons, which is developed by Jim for WP-AMILIA theme.
 * Version: 1.0.0
 * Author: Jim
 * Author URI: http://jimmee.net
 * Copyright 2018 Jimmee. All rights reserved.
 * Text Domain: page-options
 */
if(!defined('ABSPATH')){
    die();
}
define('FR_DIR', plugin_dir_path(__FILE__));
define('FR_URL', plugin_dir_url(__FILE__));
define('FR_ASSETS', FR_URL . "assets/");
define('FR_CSS', FR_URL . "assets/css/");
define('FR_JS', FR_URL . "assets/js/");
define('FR_TEMPLATES', FR_DIR . "templates" . DIRECTORY_SEPARATOR);
define('FR_INCLUDES', FR_DIR . "includes" . DIRECTORY_SEPARATOR);
define('FR_TEXT_DOMAIN', 'medical');
if(!class_exists('pageOptions')){
    class pageOptions {
        public function __construct()
        {
            $this->page_options();
        }
        public function page_options(){
          include_once FR_INCLUDES . 'page-options.php';
          if(!class_exists('ReduxFramework')){
           require_once FR_INCLUDES.'ReduxCore/framework.php';
          }
          if(!class_exists('scssc')){
           include_once FR_INCLUDES . 'scss.inc.php';
          }
        }
    }
    global $pageOptions;
    $pageOptions = new pageOptions();
}