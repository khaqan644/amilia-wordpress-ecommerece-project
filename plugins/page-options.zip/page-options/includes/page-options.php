<?php
/**
 * Meta options
 *
 * @author Jim
 * @since 1.0.0
 */
if(class_exists('CmssuperheroesCore')) {
 class CMSMetaOptions
 {
  public function __construct()
  {
   add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
  }
  /* add script */
  /* add meta boxs */
  public function add_meta_boxes()
  {
   $this->add_meta_box('template_page_options', esc_html__('Setting', 'page-options'), 'page');
   $this->add_meta_box('team_page_options', esc_html__('Team Position', 'page-options'), 'team');
   $this->add_meta_box('team_page_social', esc_html__('Team Social', 'page-options'), 'team');
   $this->add_meta_box('testimonial_page_options', esc_html__('Testimonial Position', 'page-options'), 'testimonial');
   $this->add_meta_box('pricing_page_option', esc_html__('Pricing Option', 'page-options'), 'pricing');
   $this->add_meta_box('portfolio_single_option', esc_html__('Portfolio Options', 'page-options'), 'portfolio');
  }

  public function add_meta_box($id, $label, $post_type, $context = 'advanced', $priority = 'default')
  {
   add_meta_box('_cms_' . $id, $label, array($this, $id), $post_type, $context, $priority);
  }

  /* --------------------- PAGE ---------------------- */

  function testimonial_page_options()
  {
   ?>
   <div class="team-position">
    <?php
    cms_options(array(
     'id' => 'page_testimonial_position',
     'label' => esc_html__('Testimonial Position', 'page-options'),
     'type' => 'text',
    ));
    ?>
   </div>
   <?php
  }

  function template_page_options()
  {
   ?>
   <div class="tab-container clearfix">
    <ul class='etabs clearfix'>
     <li class="tab"><a href="#tabs-general"><i class="fa fa-server"></i><?php esc_html_e('General', 'page-options'); ?>
      </a></li>
     <li class="tab"><a href="#tabs-header"><i class="fa fa-diamond"></i><?php esc_html_e('Header', 'page-options'); ?></a>
     </li>
     <li class="tab"><a href="#tabs-page-title"><i
        class="fa fa-connectdevelop"></i><?php esc_html_e('Page Title', 'page-options'); ?></a></li>
     <li class="tab"><a href="#tabs-footer"><i
        class="fa fa-connectdevelop"></i><?php esc_html_e('Footer', 'page-options'); ?></a></li>
     <li class="tab"><a href="#tabs-one-page"><?php esc_html_e('One Page', 'page-options'); ?></a></li>
    </ul>
    <div class='panel-container'>
     <div id="tabs-general">
      <?php
      cms_options(array(
       'id' => 'full_width',
       'label' => esc_html__('Full Width', 'page-options'),
       'type' => 'switch',
       'options' => array('on' => '1', 'off' => ''),
      ));
      cms_options(array(
       'id' => 'custom_revolution',
       'label' => esc_html__('Custom Revolution', 'page-options'),
       'type' => 'switch',
       'options' => array('on' => '1', 'off' => ''),
       'follow' => array('1' => array('#custom-revolution-wrap'))
      ));
      ?>
      <div id="custom-revolution-wrap">
       <?php
       cms_options(array(
        'id' => 'get_revslide',
        'label' => esc_html__('Revolution', 'page-options'),
        'type' => 'select',
        'options' => amilia_get_list_rev_slider(),
       ));
       cms_options(array(
        'id' => 'revslide_padding_bottom',
        'label' => esc_html__('Revolution slider padding bottom', 'page-options'),
        'type' => 'switch',
        'options' => array('on' => '1', 'off' => ''),
       ));
       cms_options(array(
        'id' => 'revslide_position',
        'label' => esc_html__('Revolution slider position', 'page-options'),
        'type' => 'select',
        'options' => array(
         'atop-pagetitle' => 'Atop of page title',
         'atop-primary-menu' => 'Atop of primary menu'
        ),
       ));
       ?>
      </div>
      <?php


      cms_options(array(
       'id' => 'page_general_custom_class',
       'label' => esc_html__('Body Custom Class', 'page-options'),
       'type' => 'text',
      ));
      ?>
     </div>
     <div id="tabs-header">
      <?php
      /* header. */
      cms_options(array(
       'id' => 'header',
       'label' => esc_html__('Custom', 'page-options'),
       'type' => 'switch',
       'options' => array('on' => '1', 'off' => ''),
       'follow' => array('1' => array('#page_header_enable'))
      ));
      ?>
      <div id="page_header_enable"><?php
       cms_options(array(
        'id' => 'header_layout',
        'label' => esc_html__('Layout', 'page-options'),
        'type' => 'imegesselect',
        'options' => array(
         '1' => get_template_directory_uri() . '/inc/options/images/header/header2.png',
         '2' => get_template_directory_uri() . '/inc/options/images/header/header4.png',
         '3' => get_template_directory_uri() . '/inc/options/images/header/header1.png',
         '4' => get_template_directory_uri() . '/inc/options/images/header/header3.png',
         '5' => get_template_directory_uri() . '/inc/options/images/header/header5.png',
        )
       ));
       cms_options(array(
        'id' => 'page_logo_custom',
        'label' => esc_html__('Logo', 'page-options'),
        'type' => 'image',
        'default' => '',
       ));
       cms_options(array(
        'id' => 'enable_header_fixed',
        'label' => esc_html__('Header Fixed', 'page-options'),
        'type' => 'switch',
        'options' => array('on' => '1', 'off' => ''),
        'follow' => array('1' => array('#page_header_fixed_enable'))
       ));
       ?>
       <div id="page_header_fixed_enable"><?php
        //Code here
        ?></div>
       <?php
       $menus = array();
       $menus[''] = 'Default';
       $obj_menus = wp_get_nav_menus();
       foreach ($obj_menus as $obj_menu) {
        $menus[$obj_menu->term_id] = $obj_menu->name;
       }
       $navs = get_registered_nav_menus();
       foreach ($navs as $key => $mav) {
        cms_options(array(
         'id' => $key,
         'label' => $mav,
         'type' => 'select',
         'options' => $menus
        ));
       }
       ?>
      </div>
     </div>
     <div id="tabs-page-title">
      <?php
      /* page title. */
      cms_options(array(
       'id' => 'page_title',
       'label' => esc_html__('Custom', 'page-options'),
       'type' => 'switch',
       'options' => array('on' => '1', 'off' => ''),
       'follow' => array('1' => array('#page_title_enable'))
      ));
      ?>
      <div id="page_title_enable">
       <?php
       cms_options(array(
        'id' => 'page_title_type',
        'label' => esc_html__('Page Title Style', 'page-options'),
        'type' => 'imegesselect',
        'options' => array(
         '' => get_template_directory_uri() . '/inc/options/images/pagetitle/pt-s-0.png',
         '3' => get_template_directory_uri() . '/inc/options/images/pagetitle/pt-s-1.png',
        )
       ));

       cms_options(array(
        'id' => 'page_title_text',
        'label' => esc_html__('Title', 'page-options'),
        'type' => 'text',
       ));
       ?>
      </div>
     </div>

     <div id="tabs-footer">
      <?php
      /* Footer. */
      cms_options(array(
       'id' => 'footer',
       'label' => esc_html__('Custom Footer', 'page-options'),
       'type' => 'switch',
       'options' => array('on' => '1', 'off' => ''),
       'follow' => array('1' => array('#page_footer_enable'))
      ));
      ?>
      <div id="page_footer_enable">
       <?php
       cms_options(array(
        'id' => 'disable_bottom',
        'label' => esc_html__('Hide Bottom Area', 'page-options'),
        'type' => 'select',
        'options' => array(
         'inherit' => esc_html__('Inherit', 'page-options'),
         'hide' => esc_html__('Hide', 'page-options'),
        ),
       ));
       cms_options(array(
        'id' => 'footer_layout',
        'label' => esc_html__('Layout', 'page-options'),
        'type' => 'imegesselect',
        'options' => array(
         '1' => get_template_directory_uri() . '/inc/options/images/footer/footer-1.png',
         '2' => get_template_directory_uri() . '/inc/options/images/footer/footer-2.png',
         '3' => get_template_directory_uri() . '/inc/options/images/footer/footer-3.png',
         '4' => get_template_directory_uri() . '/inc/options/images/footer/footer-4.png',
        )
       ));
       cms_options(array(
        'id' => 'footer_animate',
        'label' => esc_html__('Footer Animate', 'page-options'),
        'type' => 'switch',
        'options' => array('on' => '1', 'off' => ''),
       ));
       ?>
      </div>
     </div>

     <div id="tabs-one-page">
      <?php
      cms_options(array(
       'id' => 'one_page',
       'label' => esc_html__('Enable', 'page-options'),
       'type' => 'switch',
       'options' => array('on' => '1', 'off' => ''),
       'follow' => array('1' => array('#one-page-enable'))
      ));
      ?>
      <div id="one-page-enable">
       <?php
       cms_options(array(
        'id' => 'one_page_speed',
        'label' => esc_html__('Speed', 'page-options'),
        'type' => 'text',
        'placeholder' => '1000'
       ));
       cms_options(array(
        'id' => 'one_page_easing',
        'label' => esc_html__('Easing', 'page-options'),
        'type' => 'select',
        'options' => array(
         '' => '',
         'easeInQuad' => 'easeInQuad',
         'easeOutQuad' => 'easeOutQuad',
         'easeInOutQuad' => 'easeInOutQuad',
         'easeInCubic' => 'easeInCubic',
         'easeOutCubic' => 'easeOutCubic',
         'easeInOutCubic' => 'easeInOutCubic',
         'easeInQuart' => 'easeInQuart',
         'easeOutQuart' => 'easeOutQuart',
         'easeInOutQuart' => 'easeInOutQuart',
         'easeInQuint' => 'easeInQuint',
         'easeOutQuint' => 'easeOutQuint',
         'easeInOutQuint' => 'easeInOutQuint',
         'easeInSine' => 'easeInSine',
         'easeOutQuad' => 'easeOutQuad',
         'easeOutSine' => 'easeOutSine',
         'easeInOutSine' => 'easeInOutSine',
         'easeInExpo' => 'easeInExpo',
         'easeOutExpo' => 'easeOutExpo',
         'easeInOutExpo' => 'easeInOutExpo',
         'easeInCirc' => 'easeInCirc',
         'easeOutCirc' => 'easeOutCirc',
         'easeInOutCirc' => 'easeInOutCirc',
         'easeInElastic' => 'easeInElastic',
         'easeOutElastic' => 'easeOutElastic',
         'easeInOutElastic' => 'easeInOutElastic',
         'easeInBack' => 'easeInBack',
         'easeOutBack' => 'easeOutBack',
         'easeInOutBack' => 'easeInOutBack',
         'easeInBounce' => 'easeInBounce',
         'easeOutBounce' => 'easeOutBounce',
         'easeInOutBounce' => 'easeInOutBounce'
        )
       ));
       ?>
      </div>
     </div>
    </div>
   </div>
   <?php
  }

  /* Pricing Option */
  function pricing_page_option()
  {
   echo '<div class="pricing-option-wrap">';
   cms_options(array(
    'id' => 'price',
    'label' => esc_html__('Price', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'cents',
    'label' => esc_html__('Cents', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'time',
    'label' => esc_html__('Time', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'value',
    'label' => esc_html__('Value', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'option1',
    'label' => esc_html__('Option 1', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'option2',
    'label' => esc_html__('Option 2', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'option3',
    'label' => esc_html__('Option 3', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'option4',
    'label' => esc_html__('Option 4', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'option5',
    'label' => esc_html__('Option 5', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'option6',
    'label' => esc_html__('Option 6', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'option7',
    'label' => esc_html__('Option 7', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'option8',
    'label' => esc_html__('Option 8', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'option9',
    'label' => esc_html__('Option 9', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'option10',
    'label' => esc_html__('Option 10', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'button_url',
    'label' => esc_html__('Button Url', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'button_text',
    'label' => esc_html__('Button Text', 'page-options'),
    'type' => 'text',
   ));
   cms_options(array(
    'id' => 'is_feature',
    'label' => esc_html__('Is feature', 'page-options'),
    'type' => 'switch',
    'options' => array('on' => '1', 'off' => ''),
   ));
   /*cms_options(array(
       'id' => 'best_value',
       'label' => esc_html__('Best Value','page-options'),
       'type' => 'text',
   ));*/
   echo '</div>';
  }

  function team_page_options()
  {
   ?>
   <div class="team-position">
    <?php
    cms_options(array(
     'id' => 'page_team_position',
     'label' => esc_html__('Team Position', 'page-options'),
     'type' => 'text',
    ));
    ?>
   </div>
   <?php
  }

  function team_page_social()
  {
   ?>
   <div class="team-social">
    <?php
    cms_options(array(
     'id' => 'icon1',
     'label' => esc_html__('Icon 1', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'link1',
     'label' => esc_html__('Link 1', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'icon2',
     'label' => esc_html__('Icon 2', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'link2',
     'label' => esc_html__('Link 2', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'icon3',
     'label' => esc_html__('Icon 3', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'link3',
     'label' => esc_html__('Link 3', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'icon4',
     'label' => esc_html__('Icon 4', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'link4',
     'label' => esc_html__('Link 4', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'icon5',
     'label' => esc_html__('Icon 5', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'link5',
     'label' => esc_html__('Link 5', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'icon6',
     'label' => esc_html__('Icon 6', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'link6',
     'label' => esc_html__('Link 6', 'page-options'),
     'type' => 'text',
    ));
    ?>
   </div>
   <?php
  }

  function portfolio_single_option()
  {
   ?>
   <div class="single-portfolio">
    <?php
    cms_options(array(
     'id' => 'single_portfolio_client',
     'label' => esc_html__('Client', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'single_portfolio_skills',
     'label' => esc_html__('Skills', 'page-options'),
     'type' => 'text',
    ));
    cms_options(array(
     'id' => 'single_portfolio_url',
     'label' => esc_html__('Link to project', 'page-options'),
     'type' => 'text',
    ));
    ?>
   </div>
   <?php
  }
 }
 new CMSMetaOptions();

 if (!class_exists('reduxDashboardWidget')) {
  class reduxDashboardWidget {

   public function __construct ($parent) {
    $fname = Redux_Functions::dat( 'add_redux_dashboard', $parent->args['opt_name'] );

    add_action('wp_dashboard_setup', array($this, $fname));
   }

   public function add_redux_dashboard() {
    add_meta_box('redux_dashboard_widget', 'Redux Framework News', array($this,'redux_dashboard_widget'), 'dashboard', 'side', 'high');
   }

   public function dat() {
    return;
   }

   public function redux_dashboard_widget() {
    echo '<div class="rss-widget">';
    wp_widget_rss_output(array(
     'url'          => 'http://reduxframework.com/feed/',
     'title'        => 'REDUX_NEWS',
     'items'        => 3,
     'show_summary' => 1,
     'show_author'  => 0,
     'show_date'    => 1
    ));
    echo '</div>';
   }
  }
 }

}